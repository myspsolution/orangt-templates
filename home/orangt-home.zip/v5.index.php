<?php
  function isFromBackendLogin() {
    if (empty($_SERVER['HTTP_REFERER'])) {
        return false;
    }

    // Parse the referer URL
    $referer = parse_url($_SERVER['HTTP_REFERER']);

    // Get the current domain
    $currentDomain = $_SERVER['HTTP_HOST'];

    // Check if the referer is from the same domain and ends with "v5/auth/sign-in"
    if ($referer['host'] !== $currentDomain || strpos($referer['path'], 'v5/auth/sign-in') !== (strlen($referer['path']) - strlen('v5/auth/sign-in'))) {
        return false;
    }

    // Check if cookies "XSRF-TOKEN" and "laravel_session" exist
    if (empty($_COOKIE['XSRF-TOKEN']) || empty($_COOKIE['laravel_session'])) {
        return false;
    }

    return true;
  }

  function resetAllCookies() {
    // Loop through each cookie
    foreach ($_COOKIE as $name => $value) {
      // Unset the cookie by setting its expiration time in the past
      setcookie($name, "", time() - 3600, "/");
    }
  }

  $refererValid = isFromBackendLogin();

  if ($refererValid) {
    header("Location: /id/v5/manage/dashboard/learning");
    exit();
  } else {
    // Reset all cookies
    resetAllCookies();
    header("Location: /fe/login");
    exit();
  }
?>
