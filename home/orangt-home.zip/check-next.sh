#!/usr/bin/env bash
set -euo pipefail

PROJECT_FOLDER='/var/www/html'
HOSTNAME="$(hostname)"

stat_mtime() { stat -c %Y "$1" 2>/dev/null || echo ""; }

parse_next_version() {
  # matches: "next": "x.y.z" or "next": "^x.y.z"
  local pkg="$1" v
  v=$(
    grep -m1 -E '"next"[[:space:]]*:[[:space:]]*"\^?[0-9]+\.[0-9]+\.[0-9]+"' "$pkg" 2>/dev/null \
    | sed -nE 's/.*"next"[[:space:]]*:[[:space:]]*"\^?([0-9]+\.[0-9]+\.[0-9]+)".*/\1/p'
  )
  [[ -z "$v" ]] && return 1
  echo "$v"
}

min_required_for_major() {
  case "$1" in
    14) echo "14 2 35" ;;
    15) echo "15 5 9"  ;;
    16) echo "16 0 10" ;;
    *)  echo "" ;;
  esac
}

recommend_version() {
  case "$1" in
    14) echo "14.2.35" ;;
    15) echo "15.5.9"  ;;
    16) echo "16.0.10" ;;
    *)  echo "14.2.35" ;;
  esac
}

version_ok() {
  local x y z mx my mz
  IFS='.' read -r x y z <<<"$1"

  local mins
  mins="$(min_required_for_major "$x")"
  [[ -z "$mins" ]] && return 1

  read -r mx my mz <<<"$mins"
  (( y > my || (y == my && z >= mz) ))
}

# CSV header
printf "hostname,folder,next_version,recommendation\n"

for dir in "$PROJECT_FOLDER"/*; do
  [[ -d "$dir" ]] || continue

  folder="$(basename "$dir")"

  # ignore folders
  [[ "$folder" == *.backend || "$folder" == *.old ]] && continue

  pkg="$dir/package.json"
  [[ -f "$pkg" ]] || continue

  # ignore non-Next.js projects
  if ! next_version="$(parse_next_version "$pkg")"; then
    continue
  fi

  rec=""

  if version_ok "$next_version"; then
    # version OK → verify freshness
    pkg_mtime="$(stat_mtime "$pkg")"

    lock="$dir/package-lock.json"
    if [[ ! -f "$lock" ]]; then
      rec="warning: package-lock.json missing"
    else
      lock_mtime="$(stat_mtime "$lock")"
      (( lock_mtime >= pkg_mtime )) || rec="warning: lock older than package.json"
    fi

    nextdir="$dir/.next"
    if [[ -z "$rec" ]]; then
      if [[ ! -d "$nextdir" ]]; then
        rec="warning: .next missing"
      else
        next_mtime="$(stat_mtime "$nextdir")"
        (( next_mtime > pkg_mtime )) || rec="warning: .next older than package.json"
      fi
    fi

    # everything OK → skip output
    [[ -z "$rec" ]] && continue
  else
    IFS='.' read -r major _ <<<"$next_version"
    rec="update to $(recommend_version "$major")"
  fi

  printf "%s,%s,%s,%s\n" \
    "$HOSTNAME" \
    "$folder" \
    "$next_version" \
    "$rec"
done
