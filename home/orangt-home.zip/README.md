# orangt-home
scripts and files under orangt user home directory
