#!/bin/bash

curl -H "Content-Type: application/json" -H "X-Cassandra-Token: AstraCS:CEuEBAwzjlWuAhIMwmobkOFf:27a4f0b67af045b3f9a7853a2d3690faff49e1d7b76522be2492a37d8a3fb201" https://6be3a8f2-7c8d-4c49-bdba-55c1f33f7189-us-east-1.apps.astra.datastax.com/api/rest/v2/keyspaces/orangtclients/client/viral
