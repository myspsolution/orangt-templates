#!/bin/bash
if awk 'NR>1 {sum+=$3} END {exit !(sum>0)}' /proc/swaps; then
  echo "swap exists and > 0"
else
  echo "no swap or swap size = 0"
fi
