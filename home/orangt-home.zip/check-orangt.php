<?php

declare(strict_types=1);

/**
 * check-orangt.php
 *
 * Standalone Laravel environment checker:
 *   1. Loads a Laravel-style .env file.
 *   2. Connects to MySQL or PostgreSQL using PDO.
 *   3. Executes SELECT ... LIMIT 1 against a real application table.
 *   4. Tests configured Alibaba OSS buckets using OSS Signature V4.
 *   5. Tests AWS_* and MINIO_* S3-compatible buckets using AWS Signature V4.
 *
 * Usage:
 *   php check-orangt.php /path/to/.env
 *   php check-orangt.php /path/to/.env migrations
 *
 * The optional second argument selects a table. If omitted, the script prefers
 * the "migrations" table, then falls back to the first non-system table.
 *
 * Requirements:
 *   - PHP CLI
 *   - pdo_mysql or pdo_pgsql
 *   - curl extension for OSS/S3-compatible storage checks
 */

const EXIT_OK = 0;
const EXIT_FAILED = 1;
const EXIT_USAGE = 2;

$useColors = function_exists('stream_isatty') && stream_isatty(STDOUT);

function color(string $text, string $code): string
{
    global $useColors;

    return $useColors ? "\033[{$code}m{$text}\033[0m" : $text;
}

function printInfo(string $message): void
{
    echo color('[INFO] ', '36') . $message . PHP_EOL;
}

function printOk(string $message): void
{
    echo color('[ OK ] ', '32') . $message . PHP_EOL;
}

function printWarning(string $message): void
{
    echo color('[WARN] ', '33') . $message . PHP_EOL;
}

function printError(string $message): void
{
    fwrite(STDERR, color('[FAIL] ', '31') . $message . PHP_EOL);
}

/**
 * Parse a Laravel-style .env file without requiring Composer or vlucas/phpdotenv.
 *
 * This handles:
 *   KEY=value
 *   KEY='quoted value'
 *   KEY="quoted value"
 *   export KEY=value
 *   unquoted inline comments introduced by whitespace followed by #
 *
 * @return array<string, string>
 */
function loadEnvFile(string $path): array
{
    if (!is_file($path)) {
        throw new RuntimeException("Environment file not found: {$path}");
    }

    if (!is_readable($path)) {
        throw new RuntimeException("Environment file is not readable: {$path}");
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES);
    if ($lines === false) {
        throw new RuntimeException("Unable to read environment file: {$path}");
    }

    $env = [];

    foreach ($lines as $lineNumber => $line) {
        // Remove a possible UTF-8 BOM from the first line.
        if ($lineNumber === 0) {
            $line = preg_replace('/^\xEF\xBB\xBF/', '', $line) ?? $line;
        }

        $trimmed = trim($line);

        if ($trimmed === '' || str_starts_with($trimmed, '#')) {
            continue;
        }

        if (preg_match('/^export\s+/', $trimmed) === 1) {
            $trimmed = preg_replace('/^export\s+/', '', $trimmed, 1) ?? $trimmed;
        }

        $separator = strpos($trimmed, '=');
        if ($separator === false) {
            continue;
        }

        $key = trim(substr($trimmed, 0, $separator));
        $rawValue = trim(substr($trimmed, $separator + 1));

        if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key) !== 1) {
            continue;
        }

        $env[$key] = parseEnvValue($rawValue);
    }

    return $env;
}

function parseEnvValue(string $rawValue): string
{
    if ($rawValue === '') {
        return '';
    }

    $first = $rawValue[0];

    if ($first === "'" || $first === '"') {
        $quote = $first;
        $length = strlen($rawValue);
        $escaped = false;
        $end = null;

        for ($i = 1; $i < $length; $i++) {
            $char = $rawValue[$i];

            if ($escaped) {
                $escaped = false;
                continue;
            }

            if ($char === '\\') {
                $escaped = true;
                continue;
            }

            if ($char === $quote) {
                $end = $i;
                break;
            }
        }

        if ($end === null) {
            // Preserve the value rather than silently truncating malformed input.
            return $rawValue;
        }

        $value = substr($rawValue, 1, $end - 1);

        if ($quote === '"') {
            return strtr($value, [
                '\\"' => '"',
                '\\\\' => '\\',
                '\\n' => "\n",
                '\\r' => "\r",
                '\\t' => "\t",
                '\\$' => '$',
            ]);
        }

        return strtr($value, [
            "\\'" => "'",
            '\\\\' => '\\',
        ]);
    }

    // Strip an inline comment only when # is preceded by whitespace.
    $value = preg_replace('/\s+#.*$/', '', $rawValue);

    return trim($value ?? $rawValue);
}

function envValue(array $env, string $key, ?string $default = null): ?string
{
    return array_key_exists($key, $env) ? $env[$key] : $default;
}

function envBool(array $env, string $key, ?bool $default = null): ?bool
{
    $value = envValue($env, $key);

    if ($value === null) {
        return $default;
    }

    return match (strtolower(trim($value))) {
        '1', 'true', '(true)', 'yes', 'on' => true,
        '0', 'false', '(false)', 'no', 'off', '', 'null', '(null)' => false,
        default => $default,
    };
}

function requireEnv(array $env, string $key): string
{
    $value = envValue($env, $key);

    if ($value === null || $value === '') {
        throw new RuntimeException("Required environment variable {$key} is empty or missing.");
    }

    return $value;
}

/**
 * @return array{
 *   pdo: PDO,
 *   driver: string,
 *   database: string
 * }
 */
function connectDatabase(array $env): array
{
    $driver = strtolower(requireEnv($env, 'DB_CONNECTION'));
    $host = envValue($env, 'DB_HOST', '127.0.0.1') ?? '127.0.0.1';
    $database = requireEnv($env, 'DB_DATABASE');
    $username = requireEnv($env, 'DB_USERNAME');
    $password = envValue($env, 'DB_PASSWORD', '') ?? '';

    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 10,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    if ($driver === 'mysql') {
        if (!extension_loaded('pdo_mysql')) {
            throw new RuntimeException(
                'PHP extension pdo_mysql is not loaded. Install the matching php-mysql package.'
            );
        }

        $socket = envValue($env, 'DB_SOCKET', '') ?? '';

        if ($socket !== '') {
            $dsn = sprintf(
                'mysql:unix_socket=%s;dbname=%s;charset=utf8mb4',
                $socket,
                $database
            );
        } else {
            $port = envValue($env, 'DB_PORT', '3306') ?? '3306';
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                $host,
                $port,
                $database
            );
        }
    } elseif ($driver === 'pgsql') {
        if (!extension_loaded('pdo_pgsql')) {
            throw new RuntimeException(
                'PHP extension pdo_pgsql is not loaded. Install the matching php-pgsql package.'
            );
        }

        $port = envValue($env, 'DB_PORT', '5432') ?? '5432';
        $sslMode = envValue($env, 'DB_SSLMODE', '') ?? '';

        $dsn = sprintf(
            'pgsql:host=%s;port=%s;dbname=%s',
            $host,
            $port,
            $database
        );

        if ($sslMode !== '') {
            $dsn .= ';sslmode=' . $sslMode;
        }
    } else {
        throw new RuntimeException(
            "Unsupported DB_CONNECTION '{$driver}'. Only mysql and pgsql are supported."
        );
    }

    $pdo = new PDO($dsn, $username, $password, $options);

    return [
        'pdo' => $pdo,
        'driver' => $driver,
        'database' => $database,
    ];
}

/**
 * Select a real table and run SELECT ... LIMIT 1.
 *
 * @return array{
 *   display_name: string,
 *   row_found: bool,
 *   column_count: int
 * }
 */
function testDatabaseTable(
    PDO $pdo,
    string $driver,
    ?string $requestedTable
): array {
    if ($driver === 'mysql') {
        $statement = $pdo->query(
            "SELECT TABLE_NAME
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_TYPE = 'BASE TABLE'
             ORDER BY (TABLE_NAME = 'migrations') DESC, TABLE_NAME
            "
        );

        $tables = array_map(
            static fn(array $row): array => [
                'schema' => null,
                'table' => (string) $row['TABLE_NAME'],
            ],
            $statement->fetchAll()
        );
    } else {
        $statement = $pdo->query(
            "SELECT schemaname, tablename
             FROM pg_catalog.pg_tables
             WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
             ORDER BY (tablename = 'migrations') DESC, schemaname, tablename
            "
        );

        $tables = array_map(
            static fn(array $row): array => [
                'schema' => (string) $row['schemaname'],
                'table' => (string) $row['tablename'],
            ],
            $statement->fetchAll()
        );
    }

    if ($tables === []) {
        throw new RuntimeException('Database connection succeeded, but no application table was found.');
    }

    $selected = null;

    if ($requestedTable !== null && $requestedTable !== '') {
        foreach ($tables as $table) {
            $qualified = $table['schema'] !== null
                ? $table['schema'] . '.' . $table['table']
                : $table['table'];

            if ($requestedTable === $table['table'] || $requestedTable === $qualified) {
                $selected = $table;
                break;
            }
        }

        if ($selected === null) {
            throw new RuntimeException(
                "Requested table '{$requestedTable}' was not found in the database."
            );
        }
    } else {
        $selected = $tables[0];
    }

    if ($driver === 'mysql') {
        $quotedTable = '`' . str_replace('`', '``', $selected['table']) . '`';
        $displayName = $selected['table'];
    } else {
        $quotedSchema = '"' . str_replace('"', '""', (string) $selected['schema']) . '"';
        $quotedTableName = '"' . str_replace('"', '""', $selected['table']) . '"';
        $quotedTable = $quotedSchema . '.' . $quotedTableName;
        $displayName = $selected['schema'] . '.' . $selected['table'];
    }

    $statement = $pdo->query("SELECT * FROM {$quotedTable} LIMIT 1");
    $row = $statement->fetch();

    return [
        'display_name' => $displayName,
        'row_found' => $row !== false,
        'column_count' => $statement->columnCount(),
    ];
}

function normalizeBaseUrl(string $url): string
{
    $url = trim($url);

    if ($url === '') {
        throw new RuntimeException('OSS endpoint is empty.');
    }

    if (!preg_match('#^https?://#i', $url)) {
        $url = 'https://' . $url;
    }

    $parts = parse_url($url);

    if (
        $parts === false
        || !isset($parts['scheme'], $parts['host'])
        || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)
    ) {
        throw new RuntimeException("Invalid OSS endpoint URL: {$url}");
    }

    $path = $parts['path'] ?? '';
    if ($path !== '' && $path !== '/') {
        throw new RuntimeException(
            "OSS endpoint must not contain a path: {$url}"
        );
    }

    $authority = $parts['host'];

    if (isset($parts['port'])) {
        $authority .= ':' . $parts['port'];
    }

    return strtolower($parts['scheme']) . '://' . $authority;
}

function encodeObjectKey(string $key): string
{
    $segments = explode('/', ltrim($key, '/'));

    return implode('/', array_map('rawurlencode', $segments));
}

/**
 * Build an OSS request URL.
 *
 * Native *.aliyuncs.com endpoints use virtual-hosted bucket addressing:
 *   https://bucket.oss-region.aliyuncs.com/object
 *
 * A custom CNAME URL is used directly:
 *   https://storage.example.com/object
 */
function buildOssRequestUrl(string $baseUrl, string $bucket, string $objectKey): string
{
    $baseUrl = normalizeBaseUrl($baseUrl);
    $parts = parse_url($baseUrl);

    if ($parts === false || !isset($parts['scheme'], $parts['host'])) {
        throw new RuntimeException("Invalid OSS base URL: {$baseUrl}");
    }

    $scheme = $parts['scheme'];
    $host = $parts['host'];
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';
    $encodedKey = encodeObjectKey($objectKey);

    $isAliyunNative = preg_match('/(^|\.)aliyuncs\.com$/i', $host) === 1;
    $alreadyHasBucket = str_starts_with(strtolower($host), strtolower($bucket) . '.');

    if ($isAliyunNative && !$alreadyHasBucket) {
        $host = $bucket . '.' . $host;
    }

    return "{$scheme}://{$host}{$port}/{$encodedKey}";
}

/**
 * Execute an Alibaba OSS Signature V4 request.
 *
 * @return array{
 *   ok: bool,
 *   status: int,
 *   body: string,
 *   error: string
 * }
 */
function ossRequest(
    string $method,
    string $baseUrl,
    string $bucket,
    string $objectKey,
    string $accessKeyId,
    string $secretAccessKey,
    string $signRegion,
    string $body = ''
): array {
    if (!extension_loaded('curl')) {
        throw new RuntimeException(
            'PHP extension curl is not loaded. Install the matching php-curl package.'
        );
    }

    $method = strtoupper($method);
    $timestamp = gmdate('Ymd\THis\Z');
    $signDate = substr($timestamp, 0, 8);
    $httpDate = gmdate('D, d M Y H:i:s \G\M\T');
    $contentType = $method === 'PUT' ? 'application/octet-stream' : '';
    $contentMd5 = $method === 'PUT'
        ? base64_encode(md5($body, true))
        : '';

    $canonicalUri = rawurlencode(
        '/' . $bucket . '/' . ltrim($objectKey, '/')
    );
    $canonicalUri = str_replace('%2F', '/', $canonicalUri);

    $signedHeaders = [
        'x-oss-content-sha256' => 'UNSIGNED-PAYLOAD',
        'x-oss-date' => $timestamp,
    ];

    if ($method === 'PUT') {
        $signedHeaders['content-md5'] = $contentMd5;
        $signedHeaders['content-type'] = $contentType;
    }

    ksort($signedHeaders);

    $canonicalHeaders = '';
    foreach ($signedHeaders as $name => $value) {
        $canonicalHeaders .= strtolower($name) . ':' . trim($value) . "\n";
    }

    // No optional AdditionalHeaders are signed by this checker.
    $additionalHeaders = '';
    $canonicalQuery = '';
    $hashedPayload = 'UNSIGNED-PAYLOAD';

    $canonicalRequest =
        $method . "\n"
        . $canonicalUri . "\n"
        . $canonicalQuery . "\n"
        . $canonicalHeaders . "\n"
        . $additionalHeaders . "\n"
        . $hashedPayload;

    $scope = sprintf(
        '%s/%s/oss/aliyun_v4_request',
        $signDate,
        $signRegion
    );

    $stringToSign =
        "OSS4-HMAC-SHA256\n"
        . $timestamp . "\n"
        . $scope . "\n"
        . hash('sha256', $canonicalRequest);

    $dateKey = hash_hmac(
        'sha256',
        $signDate,
        'aliyun_v4' . $secretAccessKey,
        true
    );
    $regionKey = hash_hmac('sha256', $signRegion, $dateKey, true);
    $serviceKey = hash_hmac('sha256', 'oss', $regionKey, true);
    $signingKey = hash_hmac(
        'sha256',
        'aliyun_v4_request',
        $serviceKey,
        true
    );
    $signature = hash_hmac('sha256', $stringToSign, $signingKey);

    $authorization = sprintf(
        'OSS4-HMAC-SHA256 Credential=%s/%s,Signature=%s',
        $accessKeyId,
        $scope,
        $signature
    );

    $headers = [
        'Authorization: ' . $authorization,
        'Date: ' . $httpDate,
        'x-oss-content-sha256: UNSIGNED-PAYLOAD',
        'x-oss-date: ' . $timestamp,
    ];

    if ($method === 'PUT') {
        $headers[] = 'Content-Type: ' . $contentType;
        $headers[] = 'Content-MD5: ' . $contentMd5;
        $headers[] = 'Content-Length: ' . strlen($body);
    }

    $url = buildOssRequestUrl($baseUrl, $bucket, $objectKey);
    $curl = curl_init();

    if ($curl === false) {
        throw new RuntimeException('Unable to initialize cURL.');
    }

    $options = [
        CURLOPT_URL => $url,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_FAILONERROR => false,
    ];

    if ($method === 'PUT') {
        $options[CURLOPT_POSTFIELDS] = $body;
    }

    curl_setopt_array($curl, $options);

    $responseBody = curl_exec($curl);
    $curlError = curl_error($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

    curl_close($curl);

    if ($responseBody === false) {
        return [
            'ok' => false,
            'status' => $status,
            'body' => '',
            'error' => $curlError !== '' ? $curlError : 'Unknown cURL error',
        ];
    }

    $expectedStatuses = $method === 'PUT' ? [200] : [200, 204];

    return [
        'ok' => in_array($status, $expectedStatuses, true),
        'status' => $status,
        'body' => trim((string) $responseBody),
        'error' => $curlError,
    ];
}

function conciseOssError(array $response): string
{
    if ($response['error'] !== '') {
        return $response['error'];
    }

    if ($response['body'] !== '') {
        $body = preg_replace('/\s+/', ' ', $response['body']) ?? $response['body'];

        return substr($body, 0, 500);
    }

    return 'No response body returned by OSS.';
}

function normalizeOssSignRegion(string $region): string
{
    $region = trim(strtolower($region));
    $region = preg_replace('#^https?://#', '', $region) ?? $region;
    $region = preg_replace('/\.aliyuncs\.com$/', '', $region) ?? $region;

    // Accept both "ap-southeast-5" and Laravel-style
    // "oss-ap-southeast-5" values.
    if (str_starts_with($region, 'oss-')) {
        $region = substr($region, 4);
    }

    if (str_ends_with($region, '-internal')) {
        $region = substr($region, 0, -9);
    }

    if ($region === '' || preg_match('/^[a-z0-9-]+$/', $region) !== 1) {
        throw new RuntimeException(
            "Invalid OSS signing region '{$region}'."
        );
    }

    return $region;
}

function extractOssSignRegionFromEndpoint(string $endpoint): ?string
{
    $parts = parse_url(normalizeBaseUrl($endpoint));
    $host = is_array($parts) ? ($parts['host'] ?? '') : '';

    if (
        preg_match(
            '/(?:^|\.)oss-([a-z0-9-]+?)(?:-internal)?\.aliyuncs\.com$/i',
            $host,
            $matches
        ) === 1
    ) {
        return normalizeOssSignRegion($matches[1]);
    }

    return null;
}

/**
 * @return array{endpoint: string, sign_region: string}
 */
function deriveOssConnection(
    array $env,
    string $specificEndpointKey,
    string $specificRegionKey,
    string $specificUrlKey,
    bool $allowCommonEndpoint
): array {
    $endpointCandidates = [];

    $specificEndpoint = envValue($env, $specificEndpointKey, '') ?? '';
    if ($specificEndpoint !== '') {
        $endpointCandidates[] = $specificEndpoint;
    }

    if ($allowCommonEndpoint) {
        $commonEndpoint = envValue($env, 'OSS_ENDPOINT', '') ?? '';
        if ($commonEndpoint !== '') {
            $endpointCandidates[] = $commonEndpoint;
        }
    }

    $regionValue = envValue($env, $specificRegionKey, '') ?? '';
    if ($regionValue === '' && $specificRegionKey !== 'OSS_REGION') {
        $regionValue = envValue($env, 'OSS_REGION', '') ?? '';
    }

    $signRegion = null;

    if ($regionValue !== '') {
        $signRegion = normalizeOssSignRegion($regionValue);

        $endpointRegion = trim($regionValue);
        $endpointRegion = preg_replace(
            '#^https?://#i',
            '',
            $endpointRegion
        ) ?? $endpointRegion;
        $endpointRegion = preg_replace(
            '/\.aliyuncs\.com$/i',
            '',
            rtrim($endpointRegion, '/')
        ) ?? rtrim($endpointRegion, '/');

        if (!str_starts_with(strtolower($endpointRegion), 'oss-')) {
            $endpointRegion = 'oss-' . $endpointRegion;
        }

        $endpointCandidates[] =
            'https://' . $endpointRegion . '.aliyuncs.com';
    }

    $customUrl = envValue($env, $specificUrlKey, '') ?? '';
    if ($customUrl !== '') {
        $endpointCandidates[] = $customUrl;
    }

    $endpoint = null;

    foreach ($endpointCandidates as $candidate) {
        if (trim($candidate) !== '') {
            $endpoint = normalizeBaseUrl($candidate);
            break;
        }
    }

    if ($endpoint === null) {
        throw new RuntimeException(
            "No endpoint is available. Set {$specificEndpointKey}, "
            . "{$specificRegionKey}, or {$specificUrlKey}."
        );
    }

    if ($signRegion === null) {
        $signRegion = extractOssSignRegionFromEndpoint($endpoint);
    }

    if ($signRegion === null) {
        throw new RuntimeException(
            "OSS Signature V4 requires a region. Set {$specificRegionKey} "
            . "to a region ID such as ap-southeast-5 or oss-ap-southeast-5."
        );
    }

    return [
        'endpoint' => $endpoint,
        'sign_region' => $signRegion,
    ];
}

/**
 * Run a temporary PUT and best-effort DELETE check against one OSS bucket.
 *
 * @return array{
 *   success: bool,
 *   cleanup_success: bool,
 *   object_key: string,
 *   error: string,
 *   cleanup_error: string
 * }
 */
function testOssBucket(
    string $label,
    string $bucket,
    string $accessKeyId,
    string $secretAccessKey,
    string $endpoint,
    string $signRegion,
    string $directory
): array {
    $directory = trim($directory);
    $directory = trim($directory, '/');

    $fileName = sprintf(
        'check-orangt-%s-%s.txt',
        gmdate('Ymd-His'),
        bin2hex(random_bytes(6))
    );

    $objectKey = $directory !== ''
        ? $directory . '/' . $fileName
        : $fileName;

    $payload = implode("\n", [
        'check-orangt.php OSS write test',
        'bucket=' . $bucket,
        'label=' . $label,
        'utc=' . gmdate(DATE_ATOM),
        'host=' . (gethostname() ?: 'unknown'),
        '',
    ]);

    $put = ossRequest(
        'PUT',
        $endpoint,
        $bucket,
        $objectKey,
        $accessKeyId,
        $secretAccessKey,
        $signRegion,
        $payload
    );

    if (!$put['ok']) {
        return [
            'success' => false,
            'cleanup_success' => false,
            'object_key' => $objectKey,
            'error' => "HTTP {$put['status']}: " . conciseOssError($put),
            'cleanup_error' => '',
        ];
    }

    $delete = ossRequest(
        'DELETE',
        $endpoint,
        $bucket,
        $objectKey,
        $accessKeyId,
        $secretAccessKey,
        $signRegion
    );

    return [
        'success' => true,
        'cleanup_success' => $delete['ok'],
        'object_key' => $objectKey,
        'error' => '',
        'cleanup_error' => $delete['ok']
            ? ''
            : "HTTP {$delete['status']}: " . conciseOssError($delete),
    ];
}


/**
 * Normalize a region for AWS Signature V4.
 *
 * For Alibaba OSS configured through AWS_* variables, Laravel configurations
 * sometimes contain values such as "oss-ap-southeast-5". S3-compatible OSS
 * signing uses the general region ID, so this becomes "ap-southeast-5".
 */
function normalizeS3SigningRegion(string $region, bool $isAlibabaOss = false): string
{
    $region = trim(strtolower($region));
    $region = preg_replace('#^https?://#', '', $region) ?? $region;
    $region = preg_replace('/\\.aliyuncs\\.com$/', '', $region) ?? $region;

    if ($isAlibabaOss) {
        if (str_starts_with($region, 's3.')) {
            $region = substr($region, 3);
        }

        if (str_starts_with($region, 'oss-')) {
            $region = substr($region, 4);
        }

        if (str_ends_with($region, '-internal')) {
            $region = substr($region, 0, -9);
        }
    }

    if ($region === '' || preg_match('/^[a-z0-9][a-z0-9-]*$/', $region) !== 1) {
        throw new RuntimeException("Invalid S3 signing region '{$region}'.");
    }

    return $region;
}

function isAlibabaOssHost(string $host): bool
{
    return preg_match('/(?:^|\\.)aliyuncs\\.com$/i', $host) === 1
        && str_contains(strtolower($host), 'oss-');
}

/**
 * Convert an Alibaba OSS native endpoint to its S3-compatible endpoint.
 *
 * Example:
 *   https://oss-ap-southeast-5.aliyuncs.com
 * becomes:
 *   https://s3.oss-ap-southeast-5.aliyuncs.com
 */
function normalizeS3CompatibleEndpoint(string $endpoint): string
{
    $endpoint = normalizeBaseUrl($endpoint);
    $parts = parse_url($endpoint);

    if ($parts === false || !isset($parts['scheme'], $parts['host'])) {
        throw new RuntimeException("Invalid S3 endpoint: {$endpoint}");
    }

    $scheme = strtolower($parts['scheme']);
    $host = strtolower($parts['host']);
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';

    if (
        isAlibabaOssHost($host)
        && !str_starts_with($host, 's3.')
        && preg_match('/^oss-[a-z0-9-]+(?:-internal)?\\.aliyuncs\\.com$/', $host) === 1
    ) {
        $host = 's3.' . $host;
    }

    return "{$scheme}://{$host}{$port}";
}

/**
 * Try to derive an Alibaba OSS S3-compatible endpoint from AWS_URL.
 *
 * Example:
 *   https://bucket-name.oss-ap-southeast-5.aliyuncs.com
 * becomes:
 *   https://s3.oss-ap-southeast-5.aliyuncs.com
 */
function deriveAlibabaS3EndpointFromUrl(string $url, string $bucket): ?string
{
    if (trim($url) === '') {
        return null;
    }

    try {
        $url = normalizeBaseUrl($url);
    } catch (Throwable) {
        return null;
    }

    $parts = parse_url($url);
    $host = is_array($parts) ? strtolower($parts['host'] ?? '') : '';

    if ($host === '') {
        return null;
    }

    $bucketPrefix = strtolower($bucket) . '.';

    if (str_starts_with($host, $bucketPrefix)) {
        $host = substr($host, strlen($bucketPrefix));
    }

    if (
        preg_match('/^oss-[a-z0-9-]+(?:-internal)?\\.aliyuncs\\.com$/', $host) !== 1
    ) {
        return null;
    }

    $scheme = strtolower((string) ($parts['scheme'] ?? 'https'));
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';

    return "{$scheme}://s3.{$host}{$port}";
}

/**
 * Resolve AWS_* or MINIO_* variables into an S3-compatible connection.
 *
 * @return array{
 *   endpoint: string,
 *   region: string,
 *   path_style: bool,
 *   alibaba_oss_s3: bool
 * }
 */
function deriveS3Connection(array $env, string $prefix, string $bucket): array
{
    $prefix = strtoupper($prefix);
    $endpointKey = $prefix . '_ENDPOINT';
    $urlKey = $prefix . '_URL';
    $regionKey = $prefix === 'AWS'
        ? 'AWS_DEFAULT_REGION'
        : $prefix . '_REGION';
    $pathStyleKey = $prefix . '_USE_PATH_STYLE_ENDPOINT';

    $endpoint = trim(envValue($env, $endpointKey, '') ?? '');
    $url = trim(envValue($env, $urlKey, '') ?? '');
    $rawRegion = trim(envValue($env, $regionKey, '') ?? '');

    if ($prefix === 'MINIO' && $rawRegion === '') {
        $rawRegion = 'us-east-1';
    }

    if ($endpoint !== '') {
        $endpoint = normalizeS3CompatibleEndpoint($endpoint);
    } elseif ($prefix === 'AWS') {
        $derivedFromUrl = deriveAlibabaS3EndpointFromUrl($url, $bucket);

        if ($derivedFromUrl !== null) {
            $endpoint = $derivedFromUrl;
        } elseif ($rawRegion !== '' && str_starts_with(strtolower($rawRegion), 'oss-')) {
            $endpoint = 'https://s3.'
                . strtolower($rawRegion)
                . '.aliyuncs.com';
        } elseif ($rawRegion !== '') {
            $awsRegion = normalizeS3SigningRegion($rawRegion, false);
            $endpoint = 'https://s3.' . $awsRegion . '.amazonaws.com';
        }
    }

    if ($endpoint === '') {
        throw new RuntimeException("{$prefix}_ENDPOINT is empty or missing.");
    }

    $endpoint = normalizeS3CompatibleEndpoint($endpoint);
    $parts = parse_url($endpoint);
    $host = is_array($parts) ? strtolower($parts['host'] ?? '') : '';
    $isAlibaba = $host !== '' && isAlibabaOssHost($host);

    if ($rawRegion === '') {
        if ($isAlibaba && preg_match(
            '/(?:^|\\.)oss-([a-z0-9-]+?)(?:-internal)?\\.aliyuncs\\.com$/',
            $host,
            $matches
        ) === 1) {
            $rawRegion = $matches[1];
        } else {
            throw new RuntimeException("{$regionKey} is empty or missing.");
        }
    }

    $region = normalizeS3SigningRegion($rawRegion, $isAlibaba);

    $defaultPathStyle = $prefix === 'MINIO';
    $pathStyle = envBool($env, $pathStyleKey, $defaultPathStyle)
        ?? $defaultPathStyle;

    return [
        'endpoint' => $endpoint,
        'region' => $region,
        'path_style' => $pathStyle,
        'alibaba_oss_s3' => $isAlibaba,
    ];
}

/**
 * Build an S3 request URL and canonical URI.
 *
 * @return array{
 *   url: string,
 *   canonical_uri: string,
 *   host: string
 * }
 */
function buildS3RequestTarget(
    string $endpoint,
    string $bucket,
    string $objectKey,
    bool $pathStyle
): array {
    $endpoint = normalizeBaseUrl($endpoint);
    $parts = parse_url($endpoint);

    if ($parts === false || !isset($parts['scheme'], $parts['host'])) {
        throw new RuntimeException("Invalid S3 endpoint: {$endpoint}");
    }

    $scheme = strtolower($parts['scheme']);
    $endpointHost = strtolower($parts['host']);
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';
    $encodedKey = encodeObjectKey($objectKey);

    if ($pathStyle) {
        $host = $endpointHost . $port;
        $canonicalUri = '/' . rawurlencode($bucket) . '/' . $encodedKey;
        $url = "{$scheme}://{$host}{$canonicalUri}";
    } else {
        if (str_starts_with($endpointHost, strtolower($bucket) . '.')) {
            $host = $endpointHost . $port;
        } else {
            $host = strtolower($bucket) . '.' . $endpointHost . $port;
        }

        $canonicalUri = '/' . $encodedKey;
        $url = "{$scheme}://{$host}{$canonicalUri}";
    }

    return [
        'url' => $url,
        'canonical_uri' => $canonicalUri,
        'host' => $host,
    ];
}

/**
 * Execute a non-chunked AWS Signature Version 4 S3 request.
 *
 * This is used for AWS S3, MinIO, and Alibaba OSS when configured through
 * AWS_* variables and accessed through its S3-compatible API.
 *
 * @return array{
 *   ok: bool,
 *   status: int,
 *   body: string,
 *   error: string
 * }
 */
function s3Request(
    string $method,
    string $endpoint,
    string $bucket,
    string $objectKey,
    string $region,
    string $accessKeyId,
    string $secretAccessKey,
    bool $pathStyle,
    bool $alibabaOssS3,
    string $sessionToken = '',
    string $body = ''
): array {
    if (!extension_loaded('curl')) {
        throw new RuntimeException(
            'PHP extension curl is not loaded. Install php8.5-curl.'
        );
    }

    $method = strtoupper($method);
    $target = buildS3RequestTarget(
        $endpoint,
        $bucket,
        $objectKey,
        $pathStyle
    );

    $amzDate = gmdate('Ymd\\THis\\Z');
    $dateStamp = substr($amzDate, 0, 8);
    $payloadHash = hash('sha256', $body);

    $canonicalHeaderMap = [
        'host' => $target['host'],
        'x-amz-content-sha256' => $payloadHash,
        'x-amz-date' => $amzDate,
    ];

    if ($sessionToken !== '') {
        $canonicalHeaderMap['x-amz-security-token'] = $sessionToken;
    }

    ksort($canonicalHeaderMap, SORT_STRING);

    $canonicalHeaders = '';
    foreach ($canonicalHeaderMap as $name => $value) {
        $canonicalHeaders .= strtolower($name)
            . ':'
            . trim(preg_replace('/\\s+/', ' ', $value) ?? $value)
            . "\n";
    }

    $signedHeaders = implode(';', array_keys($canonicalHeaderMap));

    $canonicalRequest = implode("\n", [
        $method,
        $target['canonical_uri'],
        '',
        $canonicalHeaders,
        $signedHeaders,
        $payloadHash,
    ]);

    $credentialScope = sprintf(
        '%s/%s/s3/aws4_request',
        $dateStamp,
        $region
    );

    $stringToSign = implode("\n", [
        'AWS4-HMAC-SHA256',
        $amzDate,
        $credentialScope,
        hash('sha256', $canonicalRequest),
    ]);

    $dateKey = hash_hmac(
        'sha256',
        $dateStamp,
        'AWS4' . $secretAccessKey,
        true
    );
    $regionKey = hash_hmac('sha256', $region, $dateKey, true);
    $serviceKey = hash_hmac('sha256', 's3', $regionKey, true);
    $signingKey = hash_hmac(
        'sha256',
        'aws4_request',
        $serviceKey,
        true
    );
    $signature = hash_hmac('sha256', $stringToSign, $signingKey);

    $authorization = 'AWS4-HMAC-SHA256 '
        . 'Credential=' . $accessKeyId . '/' . $credentialScope
        . ', SignedHeaders=' . $signedHeaders
        . ', Signature=' . $signature;

    $headers = [
        'Authorization: ' . $authorization,
        'Host: ' . $target['host'],
        'x-amz-content-sha256: ' . $payloadHash,
        'x-amz-date: ' . $amzDate,
        'Expect:',
    ];

    if ($sessionToken !== '') {
        $headers[] = 'x-amz-security-token: ' . $sessionToken;
    }

    if ($alibabaOssS3) {
        $headers[] = 'x-oss-s3-compat: true';
    }

    if ($method === 'PUT') {
        $headers[] = 'Content-Type: application/octet-stream';
        $headers[] = 'Content-Length: ' . strlen($body);
    }

    $curl = curl_init();

    if ($curl === false) {
        throw new RuntimeException('Unable to initialize cURL.');
    }

    $options = [
        CURLOPT_URL => $target['url'],
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_FAILONERROR => false,
    ];

    if ($method === 'PUT') {
        $options[CURLOPT_POSTFIELDS] = $body;
    }

    curl_setopt_array($curl, $options);

    $responseBody = curl_exec($curl);
    $curlError = curl_error($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

    curl_close($curl);

    if ($responseBody === false) {
        return [
            'ok' => false,
            'status' => $status,
            'body' => '',
            'error' => $curlError !== '' ? $curlError : 'Unknown cURL error',
        ];
    }

    $expectedStatuses = $method === 'PUT' ? [200] : [200, 204];

    return [
        'ok' => in_array($status, $expectedStatuses, true),
        'status' => $status,
        'body' => trim((string) $responseBody),
        'error' => $curlError,
    ];
}

function conciseS3Error(array $response): string
{
    if ($response['error'] !== '') {
        return $response['error'];
    }

    if ($response['body'] !== '') {
        $body = preg_replace('/\\s+/', ' ', $response['body'])
            ?? $response['body'];

        return substr($body, 0, 500);
    }

    return 'No response body returned by the S3-compatible service.';
}

/**
 * Run a temporary PUT and best-effort DELETE check against an S3-compatible
 * bucket.
 */
function testS3Bucket(
    string $label,
    string $bucket,
    string $endpoint,
    string $region,
    string $accessKeyId,
    string $secretAccessKey,
    bool $pathStyle,
    bool $alibabaOssS3,
    string $directory = '',
    string $sessionToken = ''
): array {
    $directory = trim($directory, " \t\n\r\0\x0B/");

    $fileName = sprintf(
        'check-orangt-%s-%s.txt',
        gmdate('Ymd-His'),
        bin2hex(random_bytes(6))
    );

    $objectKey = $directory !== ''
        ? $directory . '/' . $fileName
        : $fileName;

    $payload = implode("\n", [
        'check-orangt.php S3-compatible write test',
        'bucket=' . $bucket,
        'label=' . $label,
        'utc=' . gmdate(DATE_ATOM),
        'host=' . (gethostname() ?: 'unknown'),
        '',
    ]);

    $put = s3Request(
        'PUT',
        $endpoint,
        $bucket,
        $objectKey,
        $region,
        $accessKeyId,
        $secretAccessKey,
        $pathStyle,
        $alibabaOssS3,
        $sessionToken,
        $payload
    );

    if (!$put['ok']) {
        return [
            'success' => false,
            'cleanup_success' => false,
            'object_key' => $objectKey,
            'error' => "HTTP {$put['status']}: " . conciseS3Error($put),
            'cleanup_error' => '',
        ];
    }

    $delete = s3Request(
        'DELETE',
        $endpoint,
        $bucket,
        $objectKey,
        $region,
        $accessKeyId,
        $secretAccessKey,
        $pathStyle,
        $alibabaOssS3,
        $sessionToken
    );

    return [
        'success' => true,
        'cleanup_success' => $delete['ok'],
        'object_key' => $objectKey,
        'error' => '',
        'cleanup_error' => $delete['ok']
            ? ''
            : "HTTP {$delete['status']}: " . conciseS3Error($delete),
    ];
}

/**
 * Check one environment-variable prefix such as AWS or MINIO.
 */
function runS3ProfileCheck(
    array $env,
    string $prefix,
    bool &$failed
): void {
    $prefix = strtoupper($prefix);
    $bucketKey = $prefix . '_BUCKET';
    $bucket = trim(envValue($env, $bucketKey, '') ?? '');

    if ($bucket === '') {
        printInfo(
            "{$prefix} S3 check skipped because {$bucketKey} is empty or missing."
        );
        return;
    }

    try {
        $connection = deriveS3Connection($env, $prefix, $bucket);

        if ($connection['alibaba_oss_s3']) {
            printInfo(
                "{$prefix}_* uses an Alibaba OSS endpoint; "
                . 'testing through its Amazon S3-compatible API.'
            );
        }

        printInfo(
            "Testing write access to {$bucketKey} '{$bucket}' "
            . "using {$prefix}_* variables..."
        );

        $result = testS3Bucket(
            $bucketKey,
            $bucket,
            $connection['endpoint'],
            $connection['region'],
            requireEnv($env, $prefix . '_ACCESS_KEY_ID'),
            requireEnv($env, $prefix . '_SECRET_ACCESS_KEY'),
            $connection['path_style'],
            $connection['alibaba_oss_s3'],
            envValue($env, $prefix . '_DIR', '') ?? '',
            envValue($env, $prefix . '_SESSION_TOKEN', '') ?? ''
        );

        if (!$result['success']) {
            $failed = true;
            printError(
                "{$bucketKey} write failed for object "
                . "'{$result['object_key']}': {$result['error']}"
            );
            return;
        }

        printOk(
            "{$bucketKey} write succeeded for temporary object "
            . "'{$result['object_key']}'."
        );

        if ($result['cleanup_success']) {
            printOk("{$bucketKey} temporary object deleted successfully.");
        } else {
            printWarning(
                "{$bucketKey} write passed, but cleanup failed. "
                . "Delete '{$result['object_key']}' manually. "
                . $result['cleanup_error']
            );
        }
    } catch (Throwable $exception) {
        $failed = true;
        printError(
            "{$bucketKey} check failed: " . $exception->getMessage()
        );
    }
}

function printUsage(string $scriptName): void
{
    echo "Usage:\n";
    echo "  php {$scriptName} /path/to/.env [table]\n\n";
    echo "Examples:\n";
    echo "  php {$scriptName} /var/www/html/example/.env\n";
    echo "  php {$scriptName} /var/www/html/example/.env migrations\n";
}

$scriptName = basename($argv[0] ?? 'check-orangt.php');
$envPath = $argv[1] ?? null;
$requestedTable = $argv[2] ?? null;

if ($envPath === null || in_array($envPath, ['-h', '--help'], true)) {
    printUsage($scriptName);
    exit($envPath === null ? EXIT_USAGE : EXIT_OK);
}

$failed = false;

echo color('Orangt Laravel environment check', '1') . PHP_EOL;
echo str_repeat('=', 32) . PHP_EOL;

try {
    $realEnvPath = realpath($envPath);
    $displayEnvPath = $realEnvPath !== false ? $realEnvPath : $envPath;

    $env = loadEnvFile($envPath);
    printOk("Loaded environment file: {$displayEnvPath}");
} catch (Throwable $exception) {
    printError($exception->getMessage());
    exit(EXIT_FAILED);
}

// Database check.
try {
    printInfo('Testing database connection...');

    $db = connectDatabase($env);
    printOk(
        sprintf(
            'Connected to %s database "%s".',
            $db['driver'],
            $db['database']
        )
    );

    $tableResult = testDatabaseTable(
        $db['pdo'],
        $db['driver'],
        $requestedTable
    );

    $rowDescription = $tableResult['row_found']
        ? 'one row read successfully'
        : 'table is empty, but SELECT succeeded';

    printOk(
        sprintf(
            'Table check passed: %s (%s; %d columns).',
            $tableResult['display_name'],
            $rowDescription,
            $tableResult['column_count']
        )
    );
} catch (Throwable $exception) {
    $failed = true;
    printError('Database check failed: ' . $exception->getMessage());
}

// OSS checks are determined only by configured bucket variables.
// Each OSS bucket is checked whenever its bucket variable is present and non-empty.
$primaryBucket = trim(envValue($env, 'OSS_BUCKET', '') ?? '');
$scromBucket = trim(envValue($env, 'OSS_SCROM_BUCKET', '') ?? '');

if ($primaryBucket === '') {
        printInfo('Primary OSS check skipped because OSS_BUCKET is empty or missing.');
    } else {
        try {
            printInfo("Testing write access to OSS_BUCKET '{$primaryBucket}'...");

            $connection = deriveOssConnection(
                $env,
                'OSS_ENDPOINT',
                'OSS_REGION',
                'OSS_URL',
                false
            );

            $result = testOssBucket(
                'OSS_BUCKET',
                $primaryBucket,
                requireEnv($env, 'OSS_ACCESS_KEY_ID'),
                requireEnv($env, 'OSS_SECRET_ACCESS_KEY'),
                $connection['endpoint'],
                $connection['sign_region'],
                envValue($env, 'OSS_DIR', '') ?? ''
            );

            if (!$result['success']) {
                $failed = true;
                printError(
                    "OSS_BUCKET write failed for object '{$result['object_key']}': {$result['error']}"
                );
            } else {
                printOk(
                    "OSS_BUCKET write succeeded for temporary object '{$result['object_key']}'."
                );

                if ($result['cleanup_success']) {
                    printOk('OSS_BUCKET temporary object deleted successfully.');
                } else {
                    printWarning(
                        "OSS_BUCKET write passed, but cleanup failed. "
                        . "Delete '{$result['object_key']}' manually. "
                        . $result['cleanup_error']
                    );
                }
            }
    } catch (Throwable $exception) {
        $failed = true;
        printError('OSS_BUCKET check failed: ' . $exception->getMessage());
    }
}

if ($scromBucket === '') {
        printInfo('SCROM OSS check skipped because OSS_SCROM_BUCKET is empty or missing.');
    } else {
        try {
            printInfo("Testing write access to OSS_SCROM_BUCKET '{$scromBucket}'...");

            $connection = deriveOssConnection(
                $env,
                'OSS_SCROM_ENDPOINT',
                'OSS_SCROM_REGION',
                'OSS_SCROM_URL',
                true
            );

            $result = testOssBucket(
                'OSS_SCROM_BUCKET',
                $scromBucket,
                requireEnv($env, 'OSS_SCROM_ACCESS_KEY_ID'),
                requireEnv($env, 'OSS_SCROM_SECRET_ACCESS_KEY'),
                $connection['endpoint'],
                $connection['sign_region'],
                envValue($env, 'OSS_SCROM_DIR', '') ?? ''
            );

            if (!$result['success']) {
                $failed = true;
                printError(
                    "OSS_SCROM_BUCKET write failed for object '{$result['object_key']}': {$result['error']}"
                );
            } else {
                printOk(
                    "OSS_SCROM_BUCKET write succeeded for temporary object '{$result['object_key']}'."
                );

                if ($result['cleanup_success']) {
                    printOk('OSS_SCROM_BUCKET temporary object deleted successfully.');
                } else {
                    printWarning(
                        "OSS_SCROM_BUCKET write passed, but cleanup failed. "
                        . "Delete '{$result['object_key']}' manually. "
                        . $result['cleanup_error']
                    );
                }
            }
    } catch (Throwable $exception) {
        $failed = true;
        printError('OSS_SCROM_BUCKET check failed: ' . $exception->getMessage());
    }
}

// A configured AWS_BUCKET or MINIO_BUCKET is checked whenever its bucket is non-empty.
runS3ProfileCheck($env, 'AWS', $failed);
runS3ProfileCheck($env, 'MINIO', $failed);

echo str_repeat('-', 32) . PHP_EOL;

if ($failed) {
    printError('One or more required checks failed.');
    exit(EXIT_FAILED);
}

printOk('All configured checks passed.');
exit(EXIT_OK);
