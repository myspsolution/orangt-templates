#!/usr/bin/env php
<?php

/**
 * PHP CLI script to generate CREATE INDEX statements for a MySQL database
 * and optionally execute them. By default, it only writes them to /tmp.
 *
 * Usage:
 *   create_mysql_db_indexes.php <env_file_or_domain> [execute]
 *
 * If <env_file_or_domain> is an existing file path, it is used directly.
 * Otherwise, the script uses /var/www/html/<domain>/.env.
 *
 * Use the optional "execute" argument to also run the generated .sql statements.
 */

if ($argc < 2 || $argc > 3) {
    fwrite(STDERR, "Usage:\n");
    fwrite(STDERR, "  php create_mysql_db_indexes.php [laravel_env_file_location] [execute]\n");
    fwrite(STDERR, "  - If [execute] is specified, it will run the statements.\n");
    exit(1);
}

$arg      = $argv[1];
$doExecute = (isset($argv[2]) && $argv[2] === 'execute');

/**
 * parseEnvFile
 * Reads a .env-style file (KEY=VAL) into an associative array.
 */
function parseEnvFile($filePath)
{
    if (!file_exists($filePath)) {
        fwrite(STDERR, "Error: File not found - {$filePath}\n");
        exit(1);
    }

    $params = [];
    $lines  = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        // Ignore comment lines
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) {
            [$key, $value] = $parts;
            // Remove optional quotes and whitespace
            $key   = trim($key);
            $value = trim($value);
            $value = trim($value, "'\""); // remove surrounding quotes
            $params[$key] = $value;
        }
    }
    return $params;
}

// 1. Figure out the correct .env file path
if (is_file($arg)) {
    // argument is an actual file path
    $envFilePath = realpath($arg);
} else {
    $envFilePath = "/var/www/html/{$arg}/.env";
    if (!file_exists($envFilePath)) {
        fwrite(STDERR, "Error: File not found - {$envFilePath}\n");
        exit(1);
    }
}

// 2. Parse the .env file
$dbParams = parseEnvFile($envFilePath);

// 3. Basic checks on required fields
$requiredKeys = ["DB_CONNECTION", "DB_HOST", "DB_PORT", "DB_DATABASE", "DB_USERNAME", "DB_PASSWORD"];

foreach ($requiredKeys as $rk) {
    if (empty($dbParams[$rk])) {
        fwrite(STDERR, "Error: Missing or empty '{$rk}' in .env file.\n");
        exit(1);
    }
}

if (strtolower($dbParams["DB_CONNECTION"]) !== "mysql") {
    fwrite(STDERR, "Error: DB_CONNECTION is not 'mysql'.\n");
    exit(1);
}

// 4. Connect to the database
$mysqli = @new mysqli(
    $dbParams["DB_HOST"],
    $dbParams["DB_USERNAME"],
    $dbParams["DB_PASSWORD"],
    $dbParams["DB_DATABASE"],
    (int)$dbParams["DB_PORT"]
);

if ($mysqli->connect_error) {
    fwrite(STDERR, "Error: Could not connect to database - {$mysqli->connect_error}\n");
    fwrite(STDERR, "Connection Parameters: "
        . "Host={$dbParams['DB_HOST']}, "
        . "Port={$dbParams['DB_PORT']}, "
        . "User={$dbParams['DB_USERNAME']}, "
        . "Password=*******, "
        . "Database={$dbParams['DB_DATABASE']}\n");
    exit(1);
}

// 5. Get the list of tables
$tablesResult = $mysqli->query("SHOW TABLES");
if (!$tablesResult) {
    fwrite(STDERR, "Error: Could not retrieve tables - {$mysqli->error}\n");
    $mysqli->close();
    exit(1);
}

$tables = [];
while ($row = $tablesResult->fetch_array(MYSQLI_NUM)) {
    $tables[] = $row[0];
}
$tablesResult->free();

// 6. Prepare the .sql file path
// e.g. "/tmp/create_indexes_mydb.sql"
$dbName = preg_replace('/[^A-Za-z0-9_-]+/', '_', $dbParams['DB_DATABASE']); // safe-ish
$indexFilePath = "/tmp/create_indexes_{$dbName}.sql";

$indexFileHandle = @fopen($indexFilePath, 'w');
if (!$indexFileHandle) {
    fwrite(STDERR, "Error: Unable to open file for writing: {$indexFilePath}\n");
    $mysqli->close();
    exit(1);
}

$lineCount = 0;

// 7. For each table, gather existing indexes (by column) & columns
foreach ($tables as $tableName) {
    // Gather columns that are already indexed in any index on this table
    $indexRes = $mysqli->query("SHOW INDEX FROM `{$tableName}`");
    $alreadyIndexedColumns = [];

    if ($indexRes) {
        while ($idxRow = $indexRes->fetch_assoc()) {
            $colName = strtolower($idxRow['Column_name']);
            $alreadyIndexedColumns[$colName] = true;
        }
        $indexRes->free();
    }

    // Get columns for the table
    $colsRes = $mysqli->query("SHOW COLUMNS FROM `{$tableName}`");
    if (!$colsRes) {
        fwrite(STDERR, "Warning: Could not get columns for {$tableName} - {$mysqli->error}\n");
        continue;
    }

    while ($colRow = $colsRes->fetch_assoc()) {
        $fieldName      = $colRow['Field']; // e.g. 'user_id'
        $fieldTypeRaw   = $colRow['Type'];  // e.g. 'varchar(255)'
        // Strip parentheses (e.g. "VARCHAR(255)" -> "VARCHAR")
        $fieldType      = strtoupper(preg_replace('/\(.*\)/', '', $fieldTypeRaw));
        $fieldNameLower = strtolower($fieldName);

        // Skip if this column is already indexed in any index
        if (isset($alreadyIndexedColumns[$fieldNameLower])) {
            continue;
        }

        // Decide if we want an index
        $endsWithId   = (substr($fieldNameLower, -3) === '_id');
        $startsWithIs = (substr($fieldNameLower, 0, 3) === 'is_');
        $commonTextCol = in_array($fieldNameLower, ['title','name'], true);

        // Whitelist of data types we want to index
        $indexedTypes = [
            'VARCHAR','CHAR',  // included so 'title'/'name' columns match if they're VARCHAR/CHAR
            'ENUM','BOOL','BOOLEAN','TINYINT','SMALLINT','MEDIUMINT','INT','INTEGER',
            'BIGINT','DATE','YEAR'
        ];

        // Condition: _id, is_, or (title|name), AND must be in $indexedTypes
        $shouldIndex = (
            ($endsWithId   && in_array($fieldType, $indexedTypes, true)) ||
            ($startsWithIs && in_array($fieldType, $indexedTypes, true)) ||
            ($commonTextCol && in_array($fieldType, $indexedTypes, true))
        );

        if ($shouldIndex) {
            // Build the index name
            $indexName = "{$tableName}_{$fieldName}_index";

            // MySQL index names have a max length of 64
            if (strlen($indexName) > 64) {
                $hash = md5("{$tableName}_{$fieldName}");
                $indexName = "{$hash}_index";
            }

            $createStmt = "CREATE INDEX `{$indexName}` ON `{$tableName}` (`{$fieldName}`);\n";
            fwrite($indexFileHandle, $createStmt);
            $lineCount++;
        }
    }
    $colsRes->free();
}

fclose($indexFileHandle);

// If no new indexes, we're done
if ($lineCount === 0) {
    echo "No new indexes needed.\n";
    $mysqli->close();
    exit(0);
}

// We have statements
echo "Created {$lineCount} 'CREATE INDEX' statements in:\n  {$indexFilePath}\n";

// 8. Optionally execute, if second arg == 'execute'
if ($doExecute) {
    echo "\n[EXECUTE MODE] Executing the generated statements...\n\n";

    // Read the SQL file line by line
    $lines = file($indexFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $sqlStatement) {
        // Trim to avoid empty lines
        $sqlStatement = trim($sqlStatement);
        if ($sqlStatement === '') {
            continue;
        }
        // Attempt to run
        $res = $mysqli->query($sqlStatement);
        if ($res === false) {
            echo "[ERROR] Could not execute: $sqlStatement\nMySQL error: " . $mysqli->error . "\nContinuing...\n\n";
        } else {
            echo "[OK] $sqlStatement\n";
        }
    }
}
else {
   echo "Use command:\n";
   echo "cat {$indexFilePath}\n";
   echo "to see the content of db index creator sql file";
   echo "";
}

$mysqli->close();
echo "\nDone.\n";
exit(0);
