#!/usr/bin/env bash
#/home/orangt/disable-unused-services.sh

set -euo pipefail

# ==============================
# Services safe to disable
# (edit this list as needed)
# ==============================
SERVICES=(
  apport
  gpu-manager
  pollinate
  tuned
  udisks2
  sysstat
)

sudo systemctl disable --now getty@tty1.service

# ==============================
# Disable services
# ==============================
for svc in "${SERVICES[@]}"; do
  echo "Disabling service: ${svc}"
  sudo systemctl disable --now "${svc}" || {
    echo "Warning: failed to disable ${svc} (may not exist or already disabled)"
  }
done

echo "Done."
