#!/bin/bash

# Check if the current user is "orangt"
if [ "$USER" != "orangt" ]; then
  echo "Script must be run as user 'orangt'. Exiting."
  exit 1
fi

# Check if the directory "/var/www/html" exists
if [ ! -d "/var/www/html" ]; then
  echo "Directory /var/www/html does not exist. Exiting."
  exit 1
fi

# Loop through the results of find command
find /var/www/html -type f -name artisan | while read -r artisan_file; do
  # Get the directory part of the artisan file
  DIR_PROJECT=$(dirname "$artisan_file")

  # Echo the directory
  echo "$DIR_PROJECT"

  # Change ownership of the directory to orangt:orangt
  sudo chown -R orangt:orangt "$DIR_PROJECT"

  # Navigate to the project directory
  cd "$DIR_PROJECT" || exit

  # Run the artisan optimize:clear command
  php artisan optimize:clear
done
