<?php
$locale = $_COOKIE['locale'] ?? 'id';

// Validate locale
$allowedLocales = ['id', 'en'];

if (!in_array($locale, $allowedLocales, true)) {
    $locale = 'id';
}

function resetAllCookies() {
    foreach ($_COOKIE as $name => $value) {
        if ($name === 'locale') {
            continue;
        }
        setcookie(
            $name,
            '',
            time() - 3600,
            '/'
        );
    }
}

// Reset cookies
resetAllCookies();
header("Location: /{$locale}/v5/auth/sign-in");
exit();
?>
