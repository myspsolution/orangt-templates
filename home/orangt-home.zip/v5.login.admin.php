<?php
// Start session
session_start();

$locale = $_COOKIE['locale'] ?? 'id';
$allowedLocales = ['id', 'en'];
if (!in_array($locale, $allowedLocales, true)) {
    $locale = 'id';
}
function resetAllCookies() {
    foreach ($_COOKIE as $name => $value) {
        if ($name === 'locale') {
            continue;
        }
        setcookie(
            $name,
            '',
            time() - 3600,
            '/'
        );
    }
}
// Reset cookies
resetAllCookies();
// Unset all session variables
$_SESSION = [];
// Destroy the session
session_destroy();
header("Location: /{$locale}/v5/auth/sign-in");
exit();
?>
