#!/bin/bash

# check if nginx is installed
if type nginx >/dev/null 2>&1; then
  nginx_installed=true
else
  nginx_installed=false
fi

# stop nginx service if installed
if $nginx_installed; then
  sudo systemctl stop nginx
fi

sudo rm -f /tmp/update.txt

# update and upgrade packages
# var DEBIAN_FRONTEND to make operations non-interactive
sudo DEBIAN_FRONTEND='noninteractive' apt-get -y -o Dpkg::Options::='--force-confdef' -o Dpkg::Options::='--force-confold' upgrade > /tmp/update.txt
sudo DEBIAN_FRONTEND='noninteractive' apt-get -y -o Dpkg::Options::='--force-confdef' -o Dpkg::Options::='--force-confold' dist-upgrade >> /tmp/update.txt

# remove unnecessary packages and clean up
sudo apt-get autoremove -y
sudo apt-get clean -y
sudo apt-get autoclean -y

if [ -f /var/run/reboot-required ] || grep -q '^NEEDRESTART-SVC:' /tmp/update.txt; then
    echo "reboot is required to complete the updates."
    sudo reboot
else
  if $nginx_installed; then
    sudo systemctl start nginx
  fi
fi
