#!/usr/bin/env bash
# php-fpm-advisor.sh
# prepared by dicky.dwijanto@myspsolution.com
# last update: January 6th, 2026

set -euo pipefail

PROJECT_FOLDER="/var/www/html"

warn() { echo "WARNING: $*" >&2; }
err()  { echo "ERROR: $*" >&2; }
die()  { err "$*"; exit 1; }

list_candidates() {
  echo "Usage: $(basename "$0") [folder]"
  echo
  echo "Possible params (folders under $PROJECT_FOLDER that contain .env):"
  echo
  shopt -s nullglob
  local found=0
  for envpath in "$PROJECT_FOLDER"/*/.env; do
    [[ -f "$envpath" ]] || continue
    found=1
    local folder
    folder="$(basename "$(dirname "$envpath")")"
    echo "orangt-sql $folder"
  done
  echo
  shopt -u nullglob
  [[ "$found" -eq 1 ]] || echo "(none found)"
}

# If no param OR param is empty/whitespace: list possible params and exit
if [[ $# -eq 0 ]] || [[ $# -eq 1 && -z "$(printf '%s' "${1:-}" | tr -d '[:space:]')" ]]; then
  list_candidates
  exit 0
fi

# Mandatory: exactly 1 param
if [[ $# -ne 1 ]]; then
  die "Too many arguments. Run without params to see available folders."
fi

# 1) Check harlequin installed
if ! command -v harlequin >/dev/null 2>&1; then
  warn "harlequin is not installed or not in PATH."
  exit 1
fi

PROJECT_NAME="$1"
ENV_FILE="${PROJECT_FOLDER}/${PROJECT_NAME}/.env"

# 2) Check .env exists
if [[ ! -f "$ENV_FILE" ]]; then
  die "Env file not found: $ENV_FILE"
fi

trim() {
  local s="$1"
  s="${s#"${s%%[![:space:]]*}"}"
  s="${s%"${s##*[![:space:]]}"}"
  printf '%s' "$s"
}

strip_quotes() {
  local v="$1"
  v="$(trim "$v")"
  if [[ ( "$v" == \"*\" && "$v" == *\" ) || ( "$v" == \'*\' && "$v" == *\' ) ]]; then
    v="${v:1:${#v}-2}"
  fi
  printf '%s' "$v"
}

env_get() {
  local key="$1"
  local line raw val

  line="$(
    awk -v K="$key" '
      /^[[:space:]]*#/ {next}
      /^[[:space:]]*$/ {next}
      {
        l=$0
        sub(/^[[:space:]]*/, "", l)
        sub(/^[Ee][Xx][Pp][Oo][Rr][Tt][[:space:]]+/, "", l)
        if (l ~ ("^" K "[[:space:]]*=")) { print $0; exit }
      }
    ' "$ENV_FILE"
  )"

  [[ -z "${line:-}" ]] && return 1
  raw="${line#*=}"
  val="$(strip_quotes "$raw")"
  printf '%s' "$val"
}

DB_CONNECTION="$(env_get "DB_CONNECTION" || true)"
DB_HOST="$(env_get "DB_HOST" || true)"
DB_PORT="$(env_get "DB_PORT" || true)"
DB_DATABASE="$(env_get "DB_DATABASE" || true)"
DB_USERNAME="$(env_get "DB_USERNAME" || true)"
DB_PASSWORD="$(env_get "DB_PASSWORD" || true)"

DB_CONNECTION="$(trim "${DB_CONNECTION:-}")"
DB_HOST="$(trim "${DB_HOST:-}")"
DB_PORT="$(trim "${DB_PORT:-}")"
DB_DATABASE="$(trim "${DB_DATABASE:-}")"
DB_USERNAME="$(trim "${DB_USERNAME:-}")"
DB_PASSWORD="$(trim "${DB_PASSWORD:-}")"

[[ -z "$DB_HOST" ]] && DB_HOST="127.0.0.1"

dbconn_lc="$(printf '%s' "$DB_CONNECTION" | tr '[:upper:]' '[:lower:]')"
case "$dbconn_lc" in
  mysql)
    adapter="mysql"
    [[ -z "$DB_PORT" ]] && DB_PORT="3306"
    ;;
  pgsql|postgres|postgresql|pgqsl)
    adapter="postgres"
    [[ -z "$DB_PORT" ]] && DB_PORT="5432"
    ;;
  *)
    die "Unsupported DB_CONNECTION='$DB_CONNECTION' (supported: mysql, pgsql)"
    ;;
esac

[[ -z "$DB_DATABASE" ]] && die "DB_DATABASE is empty in $ENV_FILE"
[[ -z "$DB_USERNAME" ]] && die "DB_USERNAME is empty in $ENV_FILE"

if [[ "$adapter" == "mysql" ]]; then
  exec harlequin \
    -a mysql \
    -h "$DB_HOST" \
    -p "$DB_PORT" \
    -U "$DB_USERNAME" \
    --password "$DB_PASSWORD" \
    --database "$DB_DATABASE"
else
  exec harlequin \
    -a postgres \
    -h "$DB_HOST" \
    -p "$DB_PORT" \
    -U "$DB_USERNAME" \
    --password "$DB_PASSWORD" \
    -d "$DB_DATABASE"
fi
